import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/eupdate") 
public class eupdate extends HttpServlet
{
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
            throws ServletException, IOException {  
		response.setContentType("text/html"); 
		String empid=request.getParameter("id"); 
		String jid=request.getParameter("jid");
		String tit=request.getParameter("title");
		PrintWriter out = response.getWriter();
		out.println(empid+jid+tit);
		Emp_op.update(empid,jid,tit);
		
		out.println("\nsuceessfully updated");
		//RequestDispatcher rd=request.getRequestDispatcher("view");  
       // rd.forward(request, response); 
		
    }
}
