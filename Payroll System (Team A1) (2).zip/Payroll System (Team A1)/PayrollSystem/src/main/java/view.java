import java.io.*;
import java.sql.*;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/view")
public class view extends HttpServlet 
{  
    protected void doGet(HttpServletRequest req, HttpServletResponse res)   
               throws ServletException, IOException 
    {
    	res.setContentType("text/html");
		PrintWriter out  = res.getWriter();
		List<Employee> list=Emp_op.getAllEmployees();
        try
		{
			Class.forName("com.mysql.cj.jdbc.Driver"); 
			String driverUrl = "jdbc:mysql://localhost:3307/payroll" ;
			Connection con = DriverManager.getConnection(driverUrl,"root","root");
			
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery("select * from employee");
			out.println("<html> <head>\r\n"
					+ "  	<title>Table 03</title>\r\n"
					+ "    <meta charset=\"utf-8\">\r\n"
					+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\r\n"
					+ "\r\n"
					+ "	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>\r\n"
					+ "\r\n"
					+ "	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n"
					+ "	\r\n"
					+ "	<link rel=\"stylesheet\" href=\"css/style.css\">\r\n"
					+ "\r\n"
					+ "	</head><body>\r\n"
					+ "	<section class=\"ftco-section\">\r\n"
					+ "		<div class=\"container\">\r\n"
					+ "			<div class=\"row justify-content-center\">\r\n"
					+ "				<div class=\"col-md-6 text-center mb-5\">\r\n"
					+ "					<h2 class=\"heading-section\">EMPLOYEE DETAILS</h2>\r\n"
					+ "				</div>\r\n"
					+ "			</div>\r\n"
					+ "			<div class=\"row\">\r\n"
					+ "				<div class=\"col-md-12\">\r\n"
					+ "					<div class=\"table-wrap\">");
			out.println("<table border=3 width = 40% height = 40% class=\"table\">");
			out.println("<thead bgcolor='#6807f9'><tr><th>Employee Id</th><th>Designation</th><th>Job ID</th><th>Employee Name</th><th>Date Of Birth</th><th>Phone</th><th>Mail</th><th>Gender</th><th>Pan Number</th><th>Date Of Joining</th><th>State</th><th>City</th><th>Address</th><th>Pin</th></tr></thead>");
			
			for(Employee e:list)
			{ 			
				out.println("<tr><td>"+e.getEmpid()+"</td>"+
						"<td>"+e.getTitle()+"</td>"+
			    		"<td>"+e.getJid()+"</td>"+  
			            "<td>"+e.getEname()+"</td>"+
			    		"<td>"+e.getDob()+"</td>"+
			            "<td>"+e.getPhone()+"</td>"+
			            "<td>"+e.getMail()+"</td>"+
			            "<td>"+e.getGender()+"</td>"+
			            "<td>"+e.getPanno()+"</td>"+
			            "<td>"+e.getDoj()+"</td>"+
			            "<td>"+e.getState()+"</td>"+
			            "<td>"+e.getCity()+"</td>"+
			            "<td>"+e.getAddr()+"</td>"+
			            "<td>"+e.getPin()+"</td>"+
						"<td><a href='eupdate.jsp?id="+e.getEmpid()+"'>Edit</a></td>"+  
			            "<td><a href=delete?id="+e.getEmpid()+">Delete</a></td>"+
						"</tr>");   
			}
			  
			out.println("</table>");  
            out.println("</body></html>");  
          
			/*
			 * out.println("<html><body>"); out.
			 * println("<br><br><a href='prac7_index.html'><button style='background-color: darkblue ; border: none; border-radius: 5px; color: white;  padding: 15px 32px'><b>Home Page!!</b></button></a>"
			 * ); out.println("</body></html>");
			 */
            con.close();  
           
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

   