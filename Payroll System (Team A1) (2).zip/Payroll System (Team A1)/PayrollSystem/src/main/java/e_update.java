import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/update")  
public class e_update extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String id=request.getParameter("id");  
        int eid=Integer.parseInt(id);  
        //String eid=request.getParameter("empid");  
        String jid=request.getParameter("jid");  
        String tt=request.getParameter("title");   
          
        Employee e=new Employee();  
        //e.setEmpid(eid);
        e.setJid(jid);
        e.setTitle(tt);
          
        //int status=Emp_op.update(e);  
//        if(status>0)
//        {  
//        	RequestDispatcher rd=request.getRequestDispatcher("view");  
//            rd.forward(request, response);  
//        }
//        else
//        {  
//            out.println("Sorry! unable to update record");  
//        }  
//          
//        out.close();  
    }  
  
}  