    import java.io.*;
	import jakarta.servlet.*;
	import jakarta.servlet.http.*;
	import jakarta.servlet.annotation.*;
	import java.sql.*;
	
@WebServlet(urlPatterns="/final_show")
	public class final_show extends HttpServlet{
	
		public void init() {
		}
		public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
		{
			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			String empid=req.getParameter("empid");
			String title=req.getParameter("title");
			int leaves=Integer.valueOf(req.getParameter("total_leaves_taken"));
			long salary=Long.valueOf(req.getParameter("salary"));
			//String gender=req.getParameter("gender");
			
			//out.print(enroll+"<br>"+user+"<br>"+pwd+"<br>"+gen+"<br>"+email+"<br>"+ph+"<br>"+addr+"<br>");
			out.print(empid + "<br>"+ title+"<br>"+leaves+"<br>"+ salary);
			try
			{
				String url="jdbc:mysql://localhost:3307/payroll";
				//out.print("hello1");
				Class.forName("com.mysql.cj.jdbc.Driver");//loading drive
				//out.print("hello2");
				Connection c=DriverManager.getConnection(url,"root","root");//building
				//out.print("hello3");
				String q2="insert into final_payment(emp_id,title,leaves,salary) values(?,?,?,?);";
			
				PreparedStatement ps=c.prepareStatement(q2);
				//out.print("hello4");
				ps.setString(1,empid);
				ps.setString(2,title);
				ps.setInt(3,leaves);
				ps.setLong(4,salary);
				
				int rps=ps.executeUpdate();
		
				Statement stmt = c.createStatement();
				ResultSet rst = stmt.executeQuery("select * from final_payment");
				//String q3="insert into emplogin() values(?,?,concat(char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97)));";
				out.println("<html> <head>\r\n"
						+ "  	<title>Table 03</title>\r\n"
						+ "    <meta charset=\"utf-8\">\r\n"
						+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\r\n"
						+ "\r\n"
						+ "	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>\r\n"
						+ "\r\n"
						+ "	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n"
						+ "	\r\n"
						+ "	<link rel=\"stylesheet\" href=\"css/style.css\">\r\n"
						+ "\r\n"
						+ "	</head><body>\r\n"
						+ "	<section class=\"ftco-section\">\r\n"
						+ "		<div class=\"container\">\r\n"
						+ "			<div class=\"row justify-content-center\">\r\n"
						+ "				<div class=\"col-md-6 text-center mb-5\">\r\n"
						+ "					<h2 class=\"heading-section\">EMPLOYEE DETAILS</h2>\r\n"
						+ "				</div>\r\n"
						+ "			</div>\r\n"
						+ "			<div class=\"row\">\r\n"
						+ "				<div class=\"col-md-12\">\r\n"
						+ "					<div class=\"table-wrap\">");
				out.println("<table border=3 width = 40% height = 40% class=\"table\">");
				out.println("<thead bgcolor='#6807f9'><tr><th>Employee Id</th><th>Designation</th><th>Job ID</th><th>Employee Name</th><th>Date Of Birth</th><th>Phone</th><th>Mail</th><th>Gender</th><th>Pan Number</th><th>Date Of Joining</th><th>State</th><th>City</th><th>Address</th><th>Pin</th></tr></thead>");
				
				out.println("<center><table border = 1 width = 40% height = 40></center>");
				//out.println("<caption style = \"color : grey\"><b>Electronics</b></caption>");
				out.println("<tr><th> EmpId</td><th>Title </th><th></th><th>House Pay</th><th>Medical </th><th>Other allowances</th><th>Gratuity</th><th>Deduction</th><th>Overtime</th><th>Professional Tax</th> <th> Total_salary</th></tr>");

				while(rst.next())
				{
					
				String a = rst.getString("empid");
				String b = rst.getString("title");
				int l = rst.getInt("total_leaves");
				int d = rst.getInt("total_leaves_taken");
				long k = rst.getLong("salary");

				out.println("<tr><td>" + a + "</td><td>" + b + "</td><td>" + l + "</td><td>" + d + "</td><td>" + k + "</td></tr>");
				//salary = c+d+e+f+g-h+i-j;
				}
				out.println("</table>");
				out.println("<br></br>");


				out.println("</html></body>");
				//PreparedStatement pst = conn.prepareStatement("insert into final_payment(empid,title,total_leaves_taken,salary) values(?,?,FLOOR(RAND()*(70-0+1))+0,?;");
				c.close();

				
			}
			catch(Exception e)
			{
				out.print(e.getStackTrace());
			}
		}
		public void destroy() {
		}
	}		
