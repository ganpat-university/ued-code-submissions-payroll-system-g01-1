package payroll;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import java.util.List;

import com.mysql.cj.Query;

import java.lang.*;
import java.util.Iterator;
public class pay_op 
{
	public static void insert(paypara obj) 
	{
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		
		//System.out.println("hello");
		int a=0;
		session.save(obj);
		t.commit();
		//System.out.println("Successfully Data Inserted ");
		//return a;
	}
	public static void show(paypara obj) 
	{
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query q= (Query)session.createQuery("FROM payment");
		List<paypara> empList = ((org.hibernate.query.Query) q).list();
		for (paypara p:empList)
		{
			//out.println("ID : " + p.getTitle());
		}
	}
}
