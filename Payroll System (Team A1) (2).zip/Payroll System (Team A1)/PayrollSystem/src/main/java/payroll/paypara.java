package payroll;

public class paypara 
{
	private String title;
	private long basic_pay,house_pay,medical,other_allowances,gratuity,deduction,overtime,professional_tax;
	public String getTitle() {
		return title;
	}
	public long getBasic_pay() {
		return basic_pay;
	}
	public long getHouse_pay() {
		return house_pay;
	}
	public long getMedical() {
		return medical;
	}
	public long getOther_allowances() {
		return other_allowances;
	}
	public long getGratuity() {
		return gratuity;
	}
	public long getDeduction() {
		return deduction;
	}
	public long getOvertime() {
		return overtime;
	}
	public long getProfessional_tax() {
		return professional_tax;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setBasic_pay(long basic_pay) {
		this.basic_pay = basic_pay;
	}
	public void setHouse_pay(long house_pay) {
		this.house_pay = house_pay;
	}
	public void setMedical(long medical) {
		this.medical = medical;
	}
	public void setOther_allowances(long other_allowances) {
		this.other_allowances = other_allowances;
	}
	public void setGratuity(long gratuity) {
		this.gratuity = gratuity;
	}
	public void setDeduction(long deduction) {
		this.deduction = deduction;
	}
	public void setOvertime(long overtime) {
		this.overtime = overtime;
	}
	public void setProfessional_tax(long professional_tax) {
		this.professional_tax = professional_tax;
	}
}
