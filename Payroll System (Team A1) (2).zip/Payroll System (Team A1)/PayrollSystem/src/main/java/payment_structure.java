import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.sql.*;
@WebServlet(urlPatterns="/payment_structure")
public class payment_structure extends HttpServlet
{
	
	public void init() {
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws 
	IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		try
		{
			String url="jdbc:mysql://localhost:3307/payroll";
			//out.print("hello1");
			Class.forName("com.mysql.cj.jdbc.Driver");//loading drive
			//out.print("hello2");
			Connection conn=DriverManager.getConnection(url,"root","root");//building
			//out.print("hello3");
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery("select * from payment");
			//String q3="insert into emplogin() values(?,?,concat(char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97),char(round(rand()*25)+97)));";
			out.println("<html> <head>\r\n"
					+ "  	<title>Table 03</title>\r\n"
					+ "    <meta charset=\"utf-8\">\r\n"
					+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\r\n"
					+ "\r\n"
					+ "	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>\r\n"
					+ "\r\n"
					+ "	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n"
					+ "	\r\n"
					+ "	<link rel=\"stylesheet\" href=\"css/style.css\">\r\n"
					+ "\r\n"
					+ "	</head><body>\r\n"
					+ "	<section class=\"ftco-section\">\r\n"
					+ "		<div class=\"container\">\r\n"
					+ "			<div class=\"row justify-content-center\">\r\n"
					+ "				<div class=\"col-md-6 text-center mb-5\">\r\n"
					+ "					<h2 class=\"heading-section\">EMPLOYEE DETAILS</h2>\r\n"
					+ "				</div>\r\n"
					+ "			</div>\r\n"
					+ "			<div class=\"row\">\r\n"
					+ "				<div class=\"col-md-12\">\r\n"
					+ "					<div class=\"table-wrap\">");
			out.println("<table border=3 width = 40% height = 40% class=\"table\">");
			out.println("<thead bgcolor='#6807f9'><tr><th>Title </th><th>Basic pay</th><th>House Pay</th><th>Medical </th><th>Other allowances</th><th>Gratuity</th><th>Deduction</th><th>Overtime</th><th>Professional Tax</th> <th> Total_salary</th></tr>");
		
			//out.println("<caption style = \"color : grey\"><b>Electronics</b></caption>");
			    

			while(rst.next())
			{
			//String a = rst.getString("empid");
			String b = rst.getString("title");
			long c = rst.getLong("basic_pay");
			long d = rst.getLong("house_pay");
			long e = rst.getLong("medical");
			long f = rst.getLong("other_allowances");
			long g = rst.getLong("gratuity");
			long h = rst.getLong("deduction");
			long i = rst.getLong("overtime");
			long j = rst.getLong("professional_tax");
			long k = rst.getLong("total_salary");

			out.println("<tr><td>"+ b + "</td><td>" + c + "</td><td>" + d + "</td><td>" + e + "</td><td>" + f + "</td><td>" + g + "</td><td>" + h + "</td><td>" + i + "</td><td>" + j + "</td> <td> "+ k +"</td></tr>");
			//salary = c+d+e+f+g-h+i-j;
			}
			out.println("</table>");
			out.println("<br></br>");


			out.println("</html></body>");


			//PreparedStatement pst = conn.prepareStatement("insert into final_payment(empid,title,total_leaves_taken,salary) values(?,?,FLOOR(RAND()*(70-0+1))+0,?;");
			conn.close();


			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

}
	public void destroy() {}
}