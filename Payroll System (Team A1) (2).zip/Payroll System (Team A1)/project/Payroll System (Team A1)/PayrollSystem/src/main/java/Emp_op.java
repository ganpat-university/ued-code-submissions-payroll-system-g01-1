import java.util.*;  
import java.sql.*;  
public class Emp_op 
{
	public static Connection getConnection(){  
        Connection con=null;  
        try
        {  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            con=DriverManager.getConnection("jdbc:mysql://localhost:3307/payroll","root","root");  
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }  
        return con;  
    }  
	public static int update(Employee e){  
        int status=0;  
        try{  
            Connection con=Emp_op.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update employee set jid=?,title=? where empid=?");  
            ps.setString(3,e.getEmpid());  
            ps.setString(1,e.getJid());  
            ps.setString(2,e.getTitle());
            status=ps.executeUpdate();  
              
            con.close();  
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        }  
          
        return status;  
    }  
    public static int delete(String id){  
        int status=0;  
        try
        {  
            Connection con=Emp_op.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from employee where empid=?");  
            ps.setString(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }  
          
        return status;  
    }  
    public static Employee getEmployeeById(String id)
    {  
        Employee e=new Employee();  
          
        try
        {  
            Connection con=Emp_op.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from employee where empid=?");  
            ps.setString(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next())
            {  
            	e.setEmpid(rs.getString(1));
                e.setTitle(rs.getString(2));
                e.setJid(rs.getString(3));
                e.setEname(rs.getString(4));
                e.setDob(rs.getString(5));
                e.setPhone(rs.getInt(6));
                e.setMail(rs.getString(7));
                e.setGender(rs.getString(8));
                e.setPanno(rs.getString(9));
                e.setDoj(rs.getString(10));
                e.setState(rs.getString(11));
                e.setCity(rs.getString(12));
                e.setAddr(rs.getString(13));
                e.setPin(rs.getInt(14));
            }  
            con.close();  
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        }  
          
        return e;  
    }  
    public static List<Employee> getAllEmployees(){  
        List<Employee> list=new ArrayList<Employee>();  
          
        try{  
            Connection con=Emp_op.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from employee");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next())
            {  
                Employee e=new Employee(); 
                e.setEmpid(rs.getString(1));
                e.setTitle(rs.getString(2));
                e.setJid(rs.getString(3));
                e.setEname(rs.getString(4));
                e.setDob(rs.getString(5));
                e.setPhone(rs.getInt(6));
                e.setMail(rs.getString(7));
                e.setGender(rs.getString(8));
                e.setPanno(rs.getString(9));
                e.setDoj(rs.getString(10));
                e.setState(rs.getString(11));
                e.setCity(rs.getString(12));
                e.setAddr(rs.getString(13));
                e.setPin(rs.getInt(14));
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}
