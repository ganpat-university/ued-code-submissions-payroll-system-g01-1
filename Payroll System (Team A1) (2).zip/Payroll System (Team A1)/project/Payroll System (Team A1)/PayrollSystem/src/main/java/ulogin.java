import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.sql.*;
@WebServlet(urlPatterns="/ulogin")

public class ulogin extends HttpServlet
{
	int count;
	public void init() 
	{
		count=0;	
	}
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String eid=req.getParameter("eid");
		String pwd=req.getParameter("pwd");
		String username="",pass="";
		try
		{
			String url="jdbc:mysql://localhost:3307/payroll";
			Class.forName("com.mysql.cj.jdbc.Driver");//loading drive
			Connection c=DriverManager.getConnection(url,"root","root");//building
			String q2="select empid, pwd from emplogin where empid=? and pwd=?";
			PreparedStatement ps=c.prepareStatement(q2);
			ps.setString(1,eid);
			ps.setString(2,pwd);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				username=rs.getString("empid");
				pass=rs.getString("pwd");
				out.print("hello"+username+" "+pass);
			}	
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}
		if (eid.equals(username)&&pwd.equals(pass))
		{
			HttpSession s=req.getSession();
			s.setAttribute("counter",count);
			s.setAttribute("username",username);
			s.setAttribute("pass", pass);
			//out.print("<font color=blue><h1>"+"Successfully Logged in."+"</h1></font>");
			//out.print(username);
			//out.print("<br>"+"<a href=\"alogout\">Logout</a>");
			RequestDispatcher rd=req.getRequestDispatcher("/MAIN-PAGE-.html");  
	        rd.forward(req, res);
		}
		else
		{
			
			out.print("<font color=red>"+"Wrong Password or email.");
			RequestDispatcher rd=req.getRequestDispatcher("/alogin.html");  
	        rd.include(req, res);
		}
	}
}
